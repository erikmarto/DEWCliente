$(document).ready(function(){
		
$('.photo_slider').each(function(){
	
	

});
